from setuptools import setup

setup(name='rahuliot',
version='0.1',
description='iotfiles',
author='adityarai3',
packages=['rahuliot'],
zip_safe=False)
